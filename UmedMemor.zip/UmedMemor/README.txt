UMED MEMOR - Android loiha
1) Android Studio -> File -> Open -> papkai UmedMemor
2) Sabr kuned Gradle Sync tamom shavad
3) Build -> Build APK(s)   (APK: app/build/outputs/apk/debug/)
Faili barnoma: app/src/main/assets/index.html
